﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBTG.Entities.Data
{
    public class FacultyEntity
    {
        public int FacultyId { get; set; }
        public string FacultyName { get; set; }
    }
}
