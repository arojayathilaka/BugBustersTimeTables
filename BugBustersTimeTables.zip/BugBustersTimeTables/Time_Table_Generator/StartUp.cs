﻿using BBTG.Common.Config;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;

namespace Time_Table_Generator
{
    internal class StartUp
    {
        public StartUp()
        {
            SetAppData();
        }

        private void SetAppData()
        {
            //db Environment.CurrentDirectory + "\\BBTG.db";
            //AppData.ConnectionString = $@"Data Source = BBTG.db; Version = 3; providerName=System.Data.SqlClient";
            AppData.ConnectionString = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
        }


    }
}
