﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BBTG.Common.Config
{
    public class AppData
    {
        public static string ConnectionString { get; set; }
    }
}
